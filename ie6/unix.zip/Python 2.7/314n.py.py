#!/usr/bin/env python
# -*- coding: utf-8 -*-
import urllib, urllib2, json, locale, os, sys, readline, re, traceback, lxml.html, shlex, struct
from cookielib import CookieJar
from optparse import OptionParser
from ConfigParser import SafeConfigParser

host = "http://314n.org/"
base_url = "console.php"
config_file = os.path.expanduser("~/.314n.conf")


def create_default_config(one, two, three, four):
	conf = r"""[ALIAS]
H = HELP
T = TOPIC <-n \1>[ -p \2]
B = BOARD <-n \1>[ -p \2]
F = FIRST
L = LAST
P = PREV
N = NEXT
E = EDIT <-p \1>
BS = BOARDS
TZ = TIMEZONE <-u \1>
V = RVT[ -p \1]
R = REPLY <-m \0>
D = DELETE <-p \1>
PG = PAGE <-p \1>
NT = NEWTOPIC <-t \1> <-c \2>
F5 = REFRESH

#[AUTH]
#login = 
#password = 

[IMAGES]
enabled = 0
color = 1
max_width = 200
max_height = 50
timeout = 10"""
	f = open(config_file, 'w')
	f.write(conf)
	f.close()
	print "Default config created: %s"%config_file

parser = SafeConfigParser()
aliases = {}
load_images = False
image_loading_timeout = 20
max_image_width = 500
max_image_height = 50
color_images = False
login = None
password = None

if len(parser.read(config_file)) > 0:
	try:
		if parser.has_section('ALIAS'):
			aliases = dict(parser.items('ALIAS'))
		if parser.has_option('AUTH', 'login'):
			login = parser.get("AUTH", "login")
		if parser.has_option('AUTH', 'password'):
			password = parser.get("AUTH", "password")
		if parser.has_option('IMAGES', 'enabled'):
			load_images = parser.getboolean('IMAGES', 'ENABLED')
		if parser.has_option('IMAGES', 'max_width'):
			max_image_width = parser.getint('IMAGES', 'max_width')
		if parser.has_option('IMAGES', 'max_height'):
			max_image_height = parser.getint('IMAGES', 'max_height')
		if parser.has_option('IMAGES', 'timeout'):
			image_loading_timeout = parser.getint('IMAGES', 'timeout')
		if parser.has_option('IMAGES', 'color'):
			color_images = parser.getboolean('IMAGES', 'color')
	except:
		pass

parser = OptionParser(description="CLI client for http://314n.org/", version="%prog v14.08")
parser.add_option("-u", "--user", dest="user",
                  help="login", default=os.environ.get('USER_314N'))
parser.add_option("-p", "--pass", dest="password",
                  help="password", default=os.environ.get('PASS_314N'))
parser.add_option("-i", "--enable-images",
                  action="store_true", dest="load_images", default=load_images,
                  help="show images in console")
parser.add_option("--image-max-width", dest="max_image_width",
                  default=max_image_width, type="int", help="max image width")
parser.add_option("--image-max-height", dest="max_image_height",
                  default=max_image_height, type="int", help="max image height")
parser.add_option("--image-timeout", dest="image_loading_timeout",
                  default=image_loading_timeout, type="int", help="image loading timeout")
parser.add_option("-c","--color", dest="color",
                  default=color_images, action="store_true", help="show images in color")
parser.add_option("-d","--debug", dest="debug",
                  default=False, action="store_true", help="show errors stacktrace")
parser.add_option("--create-config", action="callback", callback=create_default_config,
		  help="create default config with aliases")
(options, args) = parser.parse_args()

load_images = options.load_images
image_loading_timeout = options.image_loading_timeout
max_image_width = options.max_image_width
max_image_height = options.max_image_height
if options.user and options.password:
	login = options.user
	password = options.password
autologin = not login == None
debug = options.debug
color_images = options.color

welcome = u"""Welcome to...         <-. (`-')_ 
                         \( OO) )
 .----.  .--.   .---. ,--./ ,--/ 
\_.-,  |/_  |  / .  | |   \ |  | 
  |_  <  |  | / /|  | |  . '|  |)
.-. \  | |  |/ '-'  |||  |\    | 
\ `-'  / |  |`---|  |'|  | \   | 
 `---''  `--'    `--' `--'  `--' 


Type "HELP" to get started."""

if load_images:
	from PIL import Image, ImageOps, ImageStat
	import random, io
	from bisect import bisect
	if color_images:
		try:
			# https://gist.github.com/klange/1687427
			import image2ansi
			color_images = True
		except:
			fname = os.path.join(os.path.dirname(os.path.realpath(__file__)), "image2ansi.py")
			answer = raw_input("Image2ansi.py not found. Download it to file %s? [y/n] "%fname)
			if answer.lower() == 'y':
				url = "https://gist.githubusercontent.com/klange/1687427/raw/7bd0db367dcbe03d26478a4dfb1fc072462bb676/image-to-ansi.py"
				urllib.urlretrieve(url, fname)
				import image2ansi
				print "Image2ansi loaded"
			pass

def get_terminal_size_linux():
	def ioctl_GWINSZ(fd):
		try:
			import fcntl
			import termios
			cr = struct.unpack('hh', fcntl.ioctl(fd, termios.TIOCGWINSZ, '1234'))
			return cr
		except:
			pass
	cr = ioctl_GWINSZ(0) or ioctl_GWINSZ(1) or ioctl_GWINSZ(2)
	if not cr:
		try:
			fd = os.open(os.ctermid(), os.O_RDONLY)
			cr = ioctl_GWINSZ(fd)
			os.close(fd)
		except:
			pass
	if not cr:
		try:
			cr = (os.environ['LINES'], os.environ['COLUMNS'])
		except:
			return None
	return int(cr[1]), int(cr[0])

greyscale = [
            " ",
            " ",
            ".,-",
            "_ivc=!/|\\~",
            "gjez2]/(YL)t[+T7Vf",
            "mdK4ZGbNDXY5P*Q",
            "W8KMA",
            "#%$"
            ]
zonebounds=[36,72,108,144,180,216,252]

def imgToTxt(data):
	terminal_width = min(max_image_width,get_terminal_size_linux()[0])
	im=Image.open(data)
	divider = max(1.0*im.size[0]/terminal_width,1.0)
	if im.size[1]/divider/2 > max_image_height:
		divider = 0.5*im.size[1]/max_image_height
	if color_images:
		divider *= 2
		im = im.resize((int(im.size[0]/divider),int(im.size[1]/divider)),Image.BILINEAR)
	else:
		im = im.resize((int(im.size[0]/divider),int(im.size[1]/divider/2)),Image.BILINEAR)
	if im.mode == "RGBA":
		pixel_data = im.load()
		for y in xrange(im.size[1]):
			for x in xrange(im.size[0]):
				if pixel_data[x, y][3] < 255:
					if (x+y)%2:
						pixel_data[x, y] = (255, 255, 255, 255)
					else:
						pixel_data[x, y] = (0, 0, 0, 255)
		im = im.convert("RGB")
	result = ""
	if color_images:
		for y in xrange(im.size[1]):
		    for x in xrange(im.size[0]):
			p = im.getpixel((x,y))
			h = "%2x%2x%2x" % (p[0],p[1],p[2])
			short, rgb = image2ansi.rgb2short(h)
			result += "\033[48;5;%sm  " % short
		    result += "\033[0m\n"
		return result
	else:
		stat = ImageStat.Stat(im)
		if stat.median[0] < 128:
			im = ImageOps.invert(im)
		im=im.convert("L")
		for y in range(0,im.size[1]):
			for x in range(0,im.size[0]):
				lum=255-im.getpixel((x,y))
				row=bisect(zonebounds,lum)
				possibles=greyscale[row]
				result=result+possibles[random.randint(0,len(possibles)-1)]
			result=result+"\n"
	return result

keywords = ["BOARD", "BOARDS", "DELETE", "DONATE", "EDIT", \
	    "EXIT", "FIRST", "HELP", "INVITES", "LAST",    \
	    "LOGIN", "LOGOUT", "NEWTOPIC", "NEXT", "PAGE", \
	    "PREV", "REFRESH", "REGISTER", "REPLY", "RVT", \
	    "TIMEZONE", "TOPIC"]
bbcodes = [ "[spoiler][/spoiler]", 	\
	    "[quote][/quote]",		\
	    "[youtube][/youtube]",	\
	    "[br]",			\
	    "[img][/img]",		\
	    "[url][/url]",		\
	    "[i][/i]",			\
	    "[s][/s]",			\
	    "[u][/u]"]

keywords = keywords + [key.upper() for key in aliases.keys()]
keywords.sort()

def complete(text, state):
	count = 0
	for word in keywords:
		if word.startswith(text.upper()):
			if count == state:
				return word
			count += 1
	if len(text) > 0:
		for word in bbcodes:
			if word.startswith(text.lower()):
				if count == state:
					return word
				count += 1
	return None

def html_decode(s):
	for code in [("'", '&#39;'),('"', '&quot;'),('>', '&gt;'),('<', '&lt;'),('&', '&amp;'),(' ', '&nbsp;')]:
		s = s.replace(code[1], code[0])
	return s

def console_formatter(element, children):
    element_class = ''
    element_style = ''
    if element.attrib.has_key('class'):
	element_class = element.attrib['class']
    if element.attrib.has_key('style'):
	element_class = element.attrib['style']
    if element.tag == 'br':
	return '\n'
    if element.tag == 'a' and element.attrib.has_key('href'):
	if element.attrib['href'] != children and children:
	    return u"{text} ({link})".format(link=element.attrib['href'], text=children)
	else:
	    return u"{text}".format(text=element.attrib['href'])
    if element.tag == 'img' and element.attrib.has_key('src'):
        if load_images:
	    try:
	        fd = urllib2.urlopen(element.attrib['src'], timeout = image_loading_timeout)
                image_file = io.BytesIO(fd.read())
                return '\n'+imgToTxt(image_file)+'\n'
	    except:
		if debug:
			print traceback.format_exc()
		pass
	if element.attrib['src'] != children and children:
	    return u"{text} ({link})".format(link=element.attrib['src'], text=children)
	else:
	    return u"{text}".format(text=element.attrib['src'])
    if element.tag == 'div':
	if element_class == 'postnumber':
	    return u"\033[0;33m{text}\033[0m\n".format(text=children)
	if element_class == 'quote' :
	    return u"\033[0;36m{text}\033[0m\n".format(text=children)
	return u'\n{text}\n'.format(text=children)
    if element.tag == 'td':
	if element_class == 'post-gt':
	    return u'\n'
	if element_class == 'post-code':
	    return u"\033[0;33m{text}\033[0m\t".format(text=children)
	return u'{text}\t'.format(text=children)
    if element.tag == 'span':
      if element_style == 'text-decoration: line-through;':
	return u"\033[9m{text}\033[0m ".format(text=children)
      if element_style == 'text-decoration: underline':
	return u"\033[4m{text}\033[0m ".format(text=children)
      if element_class == 'reverse':
	  return u"\033[0;7m{text}\033[0m ".format(text=children)
      if element_class == 'spoiler':
	  return u"\033[0;7m{text}\033[0m ".format(text=children)
      if element_class == 'mark':
          return u"\033[1;37m{text}\033[0m ".format(text=children)
    if element.tag == 'tr':
	return u'\n{text}\n'.format(text=children)
    if element.tag == 'i' or element.tag == 'em':
	return u'\033[3m{text}\033[0m'.format(text=children)
    if element.tag == 'iframe' and element.attrib.has_key('src'):
	# http://i1.ytimg.com/vi/<ID>/1.jpg
	return u'{text}'.format(text=element.attrib['src'])
    if children:
	return children

def parse(node, func):
	result = []
	for element in node.xpath('child::node()'):
		if isinstance(element, lxml.html.HtmlElement):
			children = parse(element, func)
			element_result = console_formatter(element, children)
			if element_result:
				result.append(element_result)
		elif isinstance(element, lxml.html.HtmlComment):
			continue
		else:
			result.append(element)
	return u"".join(result).replace("&quot;","\"")

def html2text(message):
	message = re.sub(r"\n\s+","",message)
	document = lxml.html.fromstring(message)
	return parse(document, console_formatter).replace('\n\n','\n')

def rlinput(prompt, prefill=''):
	if len(prefill) > 0:
		readline.set_startup_hook(lambda: readline.insert_text(prefill))
	try:
		return raw_input(prompt)
	finally:
		readline.set_startup_hook()

def rep(match, args, optional):
	num = int(match.group(2))
	if len(args) <= num:
		if optional:
			return ""
		else:
			raise Exception("Argument number %d not found!"%num)
	return match.group(1)+args[num]+match.group(3)

def processAliases(cmd, aliases):
	for key in aliases.keys():
		if re.match(r"^%s\b.*"%key, cmd, re.I):
			cmd = re.match(r"^%s\b(\s+)?(.*)$"%key, cmd, re.I).group(2)
			arr = []
			if cmd and not len(cmd) == 0:
				arr = [cmd]+shlex.split(cmd)
			s = aliases[key]
			s = re.sub(r"<(.*?)\\(\d+)(.*?)>", lambda m: rep(m, arr, False), s)
			s = re.sub(r"\[(.*?)\\(\d+)(.*?)\]", lambda m: rep(m, arr, True), s)
			return s
	return cmd

path = ""
edit = ""
encoding = locale.getpreferredencoding()
cj = CookieJar()
opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))
opener.addheaders = [('User-agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:26.0) Gecko/20100101 Firefox/26.0')]
urllib2.install_opener(opener)
readline.set_completer(complete)
readline.set_completer_delims(" \n")
readline.parse_and_bind("tab: complete")
try:
	html = urllib2.urlopen(host).read()
	html = html.replace("&nbsp;<&nbsp;","&nbsp;&lt;&nbsp;")
	html = html.replace("\r\n","")
	document = lxml.html.fromstring(html)
	for br in document.xpath("*//br"):
		br.tail = "\n" + br.tail if br.tail else "\n"
	content = document.get_element_by_id("content")
	print content.text_content()
except:
	print welcome
while True:
	try:
		if autologin == 1:
			cmd = "login -u %s -p %s"%(login,password)
			autologin = 0
		else:
			cmd = rlinput(html_decode(path) + " > ", prefill=edit)
		if cmd.upper() == "EXIT":
			break
		cmd = processAliases(cmd, aliases)
		formdata = { "input" : cmd }
		data_encoded = urllib.urlencode(formdata)
		u = urllib2.urlopen(host+base_url, data_encoded)
		content = u.read()
		dict = json.loads(content)
		if dict.has_key('clear') and dict['clear'] == 1:
			os.system("clear")
		if dict.has_key('edit') and dict['edit'] == 1:
			edit = html_decode(dict['edittext'].replace('\n','[br]').encode(encoding))
		else:
			edit = ''
		if dict.has_key('path') and dict['path']:
			path = dict['path']
		if dict.has_key('message'):
			if not dict['message']:
				print "No message found in server answer."
			else:
				message = html2text(dict['message'])
				print message
	except (KeyboardInterrupt, SystemExit):
		print
		break
	except Exception, ex:
		if debug:
			print traceback.format_exc()
		else:
			print "Error: %s"%str(ex)
		pass